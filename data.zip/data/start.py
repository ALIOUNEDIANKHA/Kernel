
import script
import argparse
if __name__=="__main__":
    print('KRR or KLRR ?')
    parser = argparse.ArgumentParser()
    parser.add_argument('model_name', type=str,help='Please the model between the Kernel Ridge Regression (KRR) or Kernel Logistic Ridge Regression (KLRR) ')

    args = parser.parse_args()
    print('You give the argument : ',args.model_name)
    if args.model_name == 'KRR':
        script.KRR()
    elif (args.model_name == 'KLRR'):
        script.KLRR()
    else:
        print('Please enter a valid name')



